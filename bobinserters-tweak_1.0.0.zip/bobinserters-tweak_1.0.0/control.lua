function force_research(event)
	for i, force in pairs(game.forces) do
		for j, tech in pairs({"long-inserters-1", "long-inserters-2", "near-inserters", "more-inserters-1", "more-inserters-2"}) do
			if force.technologies[tech] and not force.technologies[tech].researched then
				force.technologies[tech].researched = true
			end
		end
	end
end

script.on_init(force_research)
script.on_configuration_changed(force_research)
script.on_event(defines.events.on_force_created, force_research)
script.on_event(defines.events.on_force_reset, force_research)
script.on_event(defines.events.on_research_reversed, force_research)
